from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse
from pydantic import BaseModel, Field
from .config import HOST, PORT, INDICATORS_FILE
from .engine import system_status, check_hash
from .events import append_event, read_events

app = FastAPI(title="FENRIR Security Dashboard", version="0.1.0")

class EventInput(BaseModel):
    kind: str = Field(default="operator_note", max_length=64)
    severity: str = Field(default="info", pattern="^(info|low|medium|high|critical)$")
    message: str = Field(min_length=1, max_length=500)

class HashInput(BaseModel):
    path: str = Field(min_length=1, max_length=1024)

@app.get("/", response_class=HTMLResponse)
def dashboard():
    return HTML

@app.get("/api/status")
def status():
    return system_status()

@app.get("/api/events")
def events(limit: int = 50):
    return read_events(max(1, min(limit, 200)))

@app.post("/api/events")
def create_event(payload: EventInput):
    return append_event(payload.kind, payload.severity, payload.message)

@app.post("/api/analyze/hash")
def analyze_hash(payload: HashInput):
    try:
        result = check_hash(payload.path, INDICATORS_FILE)
        append_event("file_hash", "high" if result["matched_indicator"] else "info",
                     "SHA-256 indicator match" if result["matched_indicator"] else "File hashed; no local indicator match",
                     {"sha256": result["sha256"], "size": result["size"]})
        return result
    except (OSError, ValueError) as exc:
        raise HTTPException(status_code=400, detail=str(exc))

HTML = r'''<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>FENRIR | Security Operations</title>
<style>
:root{color-scheme:dark;--bg:#080d14;--panel:#101a27;--line:#213246;--cyan:#48d7e8;--muted:#8ca2b8;--green:#67d6a3}
*{box-sizing:border-box}body{margin:0;background:radial-gradient(circle at 80% 0,#10283a 0,transparent 35%),var(--bg);color:#e9f1f8;font:15px system-ui,Segoe UI,sans-serif}
header{padding:24px 5vw;border-bottom:1px solid var(--line);display:flex;justify-content:space-between;align-items:center}
.brand{font-size:22px;font-weight:800;letter-spacing:4px}.brand span{color:var(--cyan)}.sub{color:var(--muted);font-size:11px;letter-spacing:2px}
main{max-width:1200px;margin:28px auto;padding:0 22px}.grid{display:grid;grid-template-columns:repeat(3,1fr);gap:16px}
.card{background:linear-gradient(145deg,#122031,#0d1520);border:1px solid var(--line);border-radius:14px;padding:20px;box-shadow:0 12px 40px #0003}
h2{font-size:13px;color:var(--muted);letter-spacing:1.5px;text-transform:uppercase;margin:0 0 14px}
.metric{font-size:27px;font-weight:700}.muted{color:var(--muted);font-size:12px}.wide{grid-column:1/-1}
button{background:#123242;border:1px solid #246072;color:#bdf7ff;padding:10px 14px;border-radius:8px;cursor:pointer}
pre{white-space:pre-wrap;overflow-wrap:anywhere;color:#b9cad9;font-size:12px}.event{padding:12px 0;border-bottom:1px solid var(--line)}.pill{color:var(--green)}
@media(max-width:760px){.grid{grid-template-columns:1fr}.wide{grid-column:auto}header{padding:18px}}
</style></head><body>
<header><div><div class="brand">FEN<span>R</span>IR</div><div class="sub">AUTONOMOUS DEFENSIVE INTELLIGENCE · v0.1.0</div></div><div class="pill">● LOCAL SYSTEM</div></header>
<main><div class="grid">
<section class="card"><h2>CPU utilization</h2><div class="metric" id="cpu">--</div><div class="muted">Host telemetry</div></section>
<section class="card"><h2>Memory utilization</h2><div class="metric" id="mem">--</div><div class="muted">Host telemetry</div></section>
<section class="card"><h2>Network interfaces</h2><div class="metric" id="ifs">--</div><div class="muted">Visible to WSL2</div></section>
<section class="card wide"><h2>System inventory</h2><pre id="inventory">Loading…</pre><button onclick="refresh()">Refresh telemetry</button></section>
<section class="card wide"><h2>Event journal</h2><div id="events" class="muted">Loading…</div></section>
<section class="card wide"><h2>Operator note</h2><input id="note" placeholder="Record an observation" style="width:min(70%,520px);padding:11px;background:#0a131e;border:1px solid #294056;color:white;border-radius:8px"><button onclick="addNote()">Record event</button></section>
</div></main>
<script>
async function refresh(){let s=await fetch('/api/status').then(r=>r.json());cpu.textContent=s.cpu_percent+'%';mem.textContent=s.memory_percent+'%';ifs.textContent=s.interfaces.length;inventory.textContent=JSON.stringify(s,null,2);let es=await fetch('/api/events').then(r=>r.json());events.innerHTML=es.length?es.map(e=>`<div class="event"><b>${e.severity.toUpperCase()}</b> · ${e.kind}<div>${e.message}</div><small>${e.timestamp}</small></div>`).join(''):'No events recorded.'}
async function addNote(){let m=note.value.trim();if(!m)return;await fetch('/api/events',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({message:m})});note.value='';refresh()}
refresh();setInterval(refresh,10000);
</script></body></html>'''
