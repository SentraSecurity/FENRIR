import hashlib
import json
import platform
import socket
from datetime import datetime, timezone
from pathlib import Path
import psutil

def utc_now():
    return datetime.now(timezone.utc).isoformat()

def system_status():
    interfaces = []
    for name, addrs in psutil.net_if_addrs().items():
        entries = []
        for addr in addrs:
            if addr.family == socket.AF_INET:
                entries.append({"address": addr.address, "netmask": addr.netmask})
        interfaces.append({"name": name, "ipv4": entries})
    return {
        "hostname": socket.gethostname(),
        "platform": platform.platform(),
        "cpu_percent": psutil.cpu_percent(interval=0.15),
        "memory_percent": psutil.virtual_memory().percent,
        "interfaces": interfaces,
        "timestamp": utc_now(),
    }

def sha256_file(path: str):
    p = Path(path).expanduser().resolve(strict=True)
    if not p.is_file():
        raise ValueError("Path is not a regular file")
    digest = hashlib.sha256()
    with p.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            digest.update(chunk)
    return {"path": str(p), "sha256": digest.hexdigest(), "size": p.stat().st_size}

def load_indicators(indicator_file: Path):
    if not indicator_file.exists():
        return set()
    return {
        line.strip().lower()
        for line in indicator_file.read_text(encoding="utf-8").splitlines()
        if line.strip() and not line.lstrip().startswith("#")
    }

def check_hash(path: str, indicator_file: Path):
    result = sha256_file(path)
    result["matched_indicator"] = result["sha256"].lower() in load_indicators(indicator_file)
    result["verdict"] = "MATCH" if result["matched_indicator"] else "NO_MATCH"
    return result
