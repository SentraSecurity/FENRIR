import os
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()
HOST = os.getenv("FENRIR_HOST", "127.0.0.1")
PORT = int(os.getenv("FENRIR_PORT", "8080"))
DATA_DIR = Path(os.getenv("FENRIR_DATA_DIR", "./data"))
DATA_DIR.mkdir(parents=True, exist_ok=True)
EVENTS_FILE = DATA_DIR / "events.jsonl"
INDICATORS_FILE = DATA_DIR / "sha256_indicators.txt"
