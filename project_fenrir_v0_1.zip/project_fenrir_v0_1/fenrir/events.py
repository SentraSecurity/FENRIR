import json
from .config import EVENTS_FILE
from .engine import utc_now

def append_event(kind: str, severity: str, message: str, details=None):
    event = {
        "timestamp": utc_now(),
        "kind": kind,
        "severity": severity,
        "message": message,
        "details": details or {},
    }
    with EVENTS_FILE.open("a", encoding="utf-8") as f:
        f.write(json.dumps(event, ensure_ascii=False) + "\n")
    return event

def read_events(limit=100):
    if not EVENTS_FILE.exists():
        return []
    rows = []
    for line in EVENTS_FILE.read_text(encoding="utf-8").splitlines()[-limit:]:
        try:
            rows.append(json.loads(line))
        except json.JSONDecodeError:
            continue
    return list(reversed(rows))
