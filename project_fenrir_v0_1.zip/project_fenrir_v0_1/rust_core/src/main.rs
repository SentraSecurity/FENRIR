use sha2::{Digest, Sha256};
use std::{env, fs::File, io::{Read, BufRead, BufReader}, path::Path};

fn hash_file(path: &str) -> Result<String, String> {
    let p = Path::new(path);
    if !p.is_file() { return Err("Not a regular file".into()); }
    let mut file = File::open(p).map_err(|e| e.to_string())?;
    let mut hasher = Sha256::new();
    let mut buffer = [0u8; 65536];
    loop {
        let n = file.read(&mut buffer).map_err(|e| e.to_string())?;
        if n == 0 { break; }
        hasher.update(&buffer[..n]);
    }
    Ok(hex::encode(hasher.finalize()))
}

fn main() {
    let args: Vec<String> = env::args().collect();
    if args.len() < 3 {
        eprintln!("Usage: fenrir-core hash <file> [indicator-list]");
        std::process::exit(2);
    }
    if args[1] != "hash" {
        eprintln!("Unknown command");
        std::process::exit(2);
    }
    match hash_file(&args[2]) {
        Ok(digest) => {
            println!("sha256={}", digest);
            if args.len() >= 4 {
                let found = File::open(&args[3]).ok().map(|f| {
                    BufReader::new(f).lines().flatten()
                        .any(|line| line.trim().eq_ignore_ascii_case(&digest))
                }).unwrap_or(false);
                println!("indicator_match={}", found);
            }
        }
        Err(err) => { eprintln!("error={}", err); std::process::exit(1); }
    }
}
