
const SpeechRecognition =
  window.SpeechRecognition ||
  window.webkitSpeechRecognition;

let recognition = null;

if (SpeechRecognition) {
  recognition = new SpeechRecognition();
  recognition.lang = "uz-UZ";
  recognition.continuous = false;
  recognition.interimResults = false;

  recognition.onresult = (event) => {
    const text = event.results[0][0].transcript;
    document.querySelector("#message").value = text;
  };

  recognition.onerror = (event) => {
    console.error("Speech error:", event.error);
  };
}

function startListening() {
  if (!recognition) {
    alert("Brauzeringiz Speech Recognitionni qo'llamaydi.");
    return;
  }
  recognition.start();
}

function speak(text) {
  if (!("speechSynthesis" in window)) return;

  speechSynthesis.cancel();

  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = "uz-UZ";
  utterance.rate = 1;
  utterance.pitch = 0.9;

  speechSynthesis.speak(utterance);
}
