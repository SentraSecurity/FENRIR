"""FENRIR persistent memory: long-term facts and episodic observations."""
import json
import sqlite3
import hashlib
from datetime import datetime, timezone
from pathlib import Path
from .config import DATA_DIR

DB_PATH = DATA_DIR / "fenrir_memory.sqlite3"

def _now():
    return datetime.now(timezone.utc).isoformat()

def _connect():
    conn = sqlite3.connect(DB_PATH, timeout=10)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn

def initialize_memory():
    with _connect() as db:
        db.executescript("""
        CREATE TABLE IF NOT EXISTS episodes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created_at TEXT NOT NULL,
            event_type TEXT NOT NULL,
            subject TEXT NOT NULL,
            outcome TEXT NOT NULL,
            severity TEXT NOT NULL,
            details_json TEXT NOT NULL,
            fingerprint TEXT NOT NULL UNIQUE
        );
        CREATE INDEX IF NOT EXISTS idx_episodes_created ON episodes(created_at);
        CREATE INDEX IF NOT EXISTS idx_episodes_subject ON episodes(subject);
        CREATE TABLE IF NOT EXISTS facts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            namespace TEXT NOT NULL,
            fact_key TEXT NOT NULL,
            fact_value TEXT NOT NULL,
            confidence REAL NOT NULL CHECK(confidence >= 0 AND confidence <= 1),
            source TEXT NOT NULL,
            UNIQUE(namespace, fact_key)
        );
        CREATE INDEX IF NOT EXISTS idx_facts_namespace ON facts(namespace);
        """)
    return {"database": str(DB_PATH), "initialized": True}

def remember_episode(event_type, subject, outcome, severity="info", details=None):
    initialize_memory()
    details = details or {}
    payload = {"event_type": str(event_type)[:80], "subject": str(subject)[:255],
               "outcome": str(outcome)[:1000], "severity": str(severity)[:20],
               "details": details}
    canonical = json.dumps(payload, sort_keys=True, ensure_ascii=False)
    fingerprint = hashlib.sha256(canonical.encode("utf-8")).hexdigest()
    with _connect() as db:
        cur = db.execute("""INSERT OR IGNORE INTO episodes
          (created_at,event_type,subject,outcome,severity,details_json,fingerprint)
          VALUES(?,?,?,?,?,?,?)""",
          (_now(), payload["event_type"], payload["subject"], payload["outcome"],
           payload["severity"], json.dumps(details, ensure_ascii=False), fingerprint))
        row = db.execute("SELECT id,created_at FROM episodes WHERE fingerprint=?", (fingerprint,)).fetchone()
    return {"id": row["id"], "created_at": row["created_at"], "duplicate": cur.rowcount == 0}

def store_fact(namespace, key, value, confidence=0.5, source="fenrir"):
    initialize_memory()
    if not 0 <= float(confidence) <= 1:
        raise ValueError("confidence must be between 0 and 1")
    now = _now()
    encoded = json.dumps(value, ensure_ascii=False)
    with _connect() as db:
        db.execute("""INSERT INTO facts(created_at,updated_at,namespace,fact_key,fact_value,confidence,source)
          VALUES(?,?,?,?,?,?,?) ON CONFLICT(namespace,fact_key) DO UPDATE SET
          updated_at=excluded.updated_at,fact_value=excluded.fact_value,
          confidence=excluded.confidence,source=excluded.source""",
          (now, now, str(namespace)[:80], str(key)[:255], encoded, float(confidence), str(source)[:255]))
    return {"namespace": namespace, "key": key, "stored": True}

def search_memory(query="", limit=20, namespace=None):
    initialize_memory()
    limit = max(1, min(int(limit), 100))
    needle = f"%{query.strip()}%"
    with _connect() as db:
        if namespace:
            facts = db.execute("SELECT * FROM facts WHERE namespace=? AND (fact_key LIKE ? OR fact_value LIKE ?) ORDER BY updated_at DESC LIMIT ?",
                               (namespace, needle, needle, limit)).fetchall()
        else:
            facts = db.execute("SELECT * FROM facts WHERE fact_key LIKE ? OR fact_value LIKE ? ORDER BY updated_at DESC LIMIT ?",
                               (needle, needle, limit)).fetchall()
        episodes = db.execute("SELECT * FROM episodes WHERE subject LIKE ? OR outcome LIKE ? OR event_type LIKE ? ORDER BY id DESC LIMIT ?",
                              (needle, needle, needle, limit)).fetchall()
    return {
      "facts": [{"namespace":r["namespace"],"key":r["fact_key"],"value":json.loads(r["fact_value"]),
                 "confidence":r["confidence"],"source":r["source"],"updated_at":r["updated_at"]} for r in facts],
      "episodes": [{"id":r["id"],"created_at":r["created_at"],"event_type":r["event_type"],
                    "subject":r["subject"],"outcome":r["outcome"],"severity":r["severity"],
                    "details":json.loads(r["details_json"])} for r in episodes]
    }

def memory_stats():
    initialize_memory()
    with _connect() as db:
        facts = db.execute("SELECT COUNT(*) FROM facts").fetchone()[0]
        episodes = db.execute("SELECT COUNT(*) FROM episodes").fetchone()[0]
    return {"long_term_facts": facts, "episodic_records": episodes, "database": str(DB_PATH)}
