"""FENRIR Brain Core: explainable defensive triage over local observations."""
from datetime import datetime, timezone
from .memory import remember_episode, store_fact, search_memory, memory_stats
from .learning import predict, _registry
from .events import append_event

BRAIN_CONFIG = {
    "architecture": "hybrid-neural",
    "memory": ["long-term", "episodic"],
    "learning_mode": "autonomous-candidate-learning",
    "deployment_policy": "human-approval-required",
    "external_actions": "disabled-by-default",
}

def brain_status():
    return {"name": "FENRIR AI BRAIN", "version": "0.3.0", "state": "operational",
            "configuration": BRAIN_CONFIG, "memory": memory_stats(),
            "active_model": _registry().get("active"),
            "timestamp": datetime.now(timezone.utc).isoformat()}

def observe(event_type, subject, details=None, severity="info", outcome="observed"):
    """Record an observation. This does not execute, contact, or modify a target."""
    details = details or {}
    episode = remember_episode(event_type, subject, outcome, severity, details)
    append_event("brain_observation", severity, f"Observed: {subject}",
                 {"event_type": event_type, "episode_id": episode["id"]})
    return {"accepted": True, "episode": episode, "memory": memory_stats()}

def assess_features(features):
    """Use the currently approved model; otherwise return a transparent baseline status."""
    active = _registry().get("active")
    if not active:
        result = {"status": "no_approved_model", "prediction": None,
                  "explanation": "Approved model is unavailable; no ML verdict was produced."}
    else:
        import json
        from pathlib import Path
        model = json.loads(Path(active["path"]).read_text(encoding="utf-8"))
        result = {"status": "scored", **predict(model, features),
                  "model_version": active["version"],
                  "explanation": "Score is a triage signal, not proof of compromise."}
    remember_episode("feature_assessment", "local-feature-vector", result.get("status", "unknown"),
                     "info", {"result": result})
    return result

def learn_fact(namespace, key, value, confidence, source, human_reviewed=False):
    """Long-term knowledge accepts only explicitly reviewed facts in this release."""
    if human_reviewed is not True:
        raise ValueError("Long-term facts require human_reviewed=true")
    saved = store_fact(namespace, key, value, confidence, source)
    append_event("brain_memory", "info", "Reviewed fact stored", saved)
    return saved

def recall(query="", limit=20):
    return search_memory(query, limit)
