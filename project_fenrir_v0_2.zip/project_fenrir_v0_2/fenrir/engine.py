import hashlib, platform, socket
import psutil
from datetime import datetime, timezone

def system_status():
    interfaces = []
    for name, addrs in psutil.net_if_addrs().items():
        ipv4 = [{"address": a.address, "netmask": a.netmask}
                for a in addrs if a.family == socket.AF_INET]
        interfaces.append({"name": name, "ipv4": ipv4})
    return {"hostname": socket.gethostname(), "platform": platform.platform(),
            "cpu_percent": psutil.cpu_percent(interval=0.1),
            "memory_percent": psutil.virtual_memory().percent,
            "interfaces": interfaces, "timestamp": datetime.now(timezone.utc).isoformat()}

def hash_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""): h.update(chunk)
    return h.hexdigest()
