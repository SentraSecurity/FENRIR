from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse
from pydantic import BaseModel, Field
from .engine import system_status
from .events import read_events
from .learning import import_feed, train_candidate, approve_candidate, rollback, learning_status, _read_jsonl
from .config import INDICATORS_FILE

app=FastAPI(title="FENRIR Security Dashboard",version="0.2.0")

class FeedInput(BaseModel):
    path:str=Field(min_length=1,max_length=1024)
    source:str=Field(min_length=2,max_length=100)
class CandidateInput(BaseModel):
    candidate_id:str=Field(min_length=5,max_length=80)
class RollbackInput(BaseModel):
    version:str=Field(min_length=5,max_length=80)

@app.get("/",response_class=HTMLResponse)
def dashboard(): return HTML
@app.get("/api/status")
def status(): return system_status()
@app.get("/api/events")
def events(limit:int=50): return read_events(max(1,min(limit,200)))
@app.get("/api/learning/status")
def lstatus(): return learning_status()
@app.get("/api/learning/indicators")
def indicators(): return _read_jsonl(INDICATORS_FILE)[-100:]
@app.post("/api/learning/import")
def feed(payload:FeedInput):
    try: return import_feed(payload.path,payload.source)
    except Exception as e: raise HTTPException(400,str(e))
@app.post("/api/learning/train")
def train():
    try: return train_candidate()
    except Exception as e: raise HTTPException(400,str(e))
@app.post("/api/learning/approve")
def approve(payload:CandidateInput):
    try: return approve_candidate(payload.candidate_id)
    except Exception as e: raise HTTPException(400,str(e))
@app.post("/api/learning/rollback")
def rb(payload:RollbackInput):
    try: return rollback(payload.version)
    except Exception as e: raise HTTPException(400,str(e))

HTML=r'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>FENRIR | Security Operations</title><style>
:root{color-scheme:dark;--bg:#080d14;--panel:#101a27;--line:#213246;--cyan:#48d7e8;--muted:#8ca2b8;--green:#67d6a3}
*{box-sizing:border-box}body{margin:0;background:radial-gradient(circle at 80% 0,#10283a 0,transparent 35%),var(--bg);color:#e9f1f8;font:14px system-ui}
header{padding:22px 5vw;border-bottom:1px solid var(--line);display:flex;justify-content:space-between}.brand{font-size:22px;font-weight:800;letter-spacing:4px}.brand span{color:var(--cyan)}.muted{color:var(--muted);font-size:12px}
main{max-width:1200px;margin:28px auto;padding:0 20px}.grid{display:grid;grid-template-columns:repeat(3,1fr);gap:15px}.card{background:linear-gradient(145deg,#122031,#0d1520);border:1px solid var(--line);border-radius:13px;padding:18px}.wide{grid-column:1/-1}h2{font-size:12px;color:var(--muted);letter-spacing:1.4px}.metric{font-size:26px;font-weight:700}button{background:#123242;border:1px solid #246072;color:#bdf7ff;padding:9px 13px;border-radius:8px;cursor:pointer;margin:4px}pre{white-space:pre-wrap;overflow-wrap:anywhere;color:#b9cad9;font-size:12px}.row{padding:9px 0;border-bottom:1px solid var(--line)}@media(max-width:760px){.grid{grid-template-columns:1fr}.wide{grid-column:auto}}
</style></head><body><header><div><div class="brand">FEN<span>R</span>IR</div><div class="muted">LEARNING ENGINE · v0.2.0</div></div><div style="color:var(--green)">● LOCAL DEFENSE</div></header>
<main><div class="grid">
<section class="card"><h2>CPU</h2><div class="metric" id="cpu">--</div></section>
<section class="card"><h2>MEMORY</h2><div class="metric" id="mem">--</div></section>
<section class="card"><h2>NETWORK INTERFACES</h2><div class="metric" id="ifs">--</div></section>
<section class="card"><h2>TRAINING SAMPLES</h2><div class="metric" id="samples">--</div></section>
<section class="card"><h2>THREAT INDICATORS</h2><div class="metric" id="indicators">--</div></section>
<section class="card"><h2>ACTIVE MODEL</h2><div class="metric" id="model" style="font-size:15px">None</div></section>
<section class="card wide"><h2>LEARNING PIPELINE</h2><p class="muted">Import reviewed local feed → prepare human-reviewed labels → train candidate → inspect metrics → approve manually.</p><button onclick="refresh()">Refresh telemetry</button><button onclick="train()">Train candidate</button><pre id="learning">Loading…</pre></section>
<section class="card wide"><h2>EVENT JOURNAL</h2><div id="events" class="muted">Loading…</div></section>
</div></main><script>
async function refresh(){let s=await fetch('/api/status').then(r=>r.json());cpu.textContent=s.cpu_percent+'%';mem.textContent=s.memory_percent+'%';ifs.textContent=s.interfaces.length;
let l=await fetch('/api/learning/status').then(r=>r.json());samples.textContent=l.sample_count;indicators.textContent=l.indicator_count;model.textContent=l.active_model?.version||'Not promoted';learning.textContent=JSON.stringify(l,null,2);
let e=await fetch('/api/events').then(r=>r.json());events.innerHTML=e.length?e.map(x=>`<div class="row"><b>${x.severity.toUpperCase()}</b> · ${x.kind}<div>${x.message}</div><small>${x.timestamp}</small></div>`).join(''):'No events recorded.'}
async function train(){let r=await fetch('/api/learning/train',{method:'POST'});let j=await r.json();alert(JSON.stringify(j,null,2));refresh()}
refresh();setInterval(refresh,15000);
</script></body></html>'''
