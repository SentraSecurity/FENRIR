import argparse, json
from .learning import import_feed, train_candidate, approve_candidate, rollback, learning_status

def main():
    p=argparse.ArgumentParser(prog="fenrir"); sub=p.add_subparsers(dest="cmd",required=True)
    imp=sub.add_parser("import-feed"); imp.add_argument("path"); imp.add_argument("--source",required=True)
    sub.add_parser("train")
    sub.add_parser("status")
    app=sub.add_parser("approve"); app.add_argument("candidate_id")
    rb=sub.add_parser("rollback"); rb.add_argument("version")
    a=p.parse_args()
    try:
        if a.cmd=="import-feed": out=import_feed(a.path,a.source)
        elif a.cmd=="train": out=train_candidate()
        elif a.cmd=="status": out=learning_status()
        elif a.cmd=="approve": out=approve_candidate(a.candidate_id)
        else: out=rollback(a.version)
        print(json.dumps(out,indent=2))
    except Exception as e:
        p.exit(1, f"FENRIR error: {e}\\n")

if __name__=="__main__": main()
