import json
from .config import EVENTS_FILE
from datetime import datetime, timezone

def append_event(kind, severity, message, details=None):
    event = {"timestamp": datetime.now(timezone.utc).isoformat(),
             "kind": kind, "severity": severity, "message": message, "details": details or {}}
    with EVENTS_FILE.open("a", encoding="utf-8") as f:
        f.write(json.dumps(event) + "\n")
    return event

def read_events(limit=100):
    if not EVENTS_FILE.exists(): return []
    result = []
    for line in EVENTS_FILE.read_text(encoding="utf-8").splitlines()[-limit:]:
        try: result.append(json.loads(line))
        except json.JSONDecodeError: pass
    return list(reversed(result))
