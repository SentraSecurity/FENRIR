import os
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()
HOST = os.getenv("FENRIR_HOST", "127.0.0.1")
PORT = int(os.getenv("FENRIR_PORT", "8080"))
DATA_DIR = Path(os.getenv("FENRIR_DATA_DIR", "./data")).resolve()
DATA_DIR.mkdir(parents=True, exist_ok=True)
MODEL_DIR = DATA_DIR / "models"
MODEL_DIR.mkdir(parents=True, exist_ok=True)
EVENTS_FILE = DATA_DIR / "events.jsonl"
INDICATORS_FILE = DATA_DIR / "indicators.jsonl"
LABELED_FILE = DATA_DIR / "labeled_samples.jsonl"
REGISTRY_FILE = DATA_DIR / "registry.json"
MIN_TRAIN_SAMPLES = int(os.getenv("FENRIR_MIN_TRAIN_SAMPLES", "20"))
MIN_PRECISION = float(os.getenv("FENRIR_MIN_PRECISION", "0.80"))
MIN_RECALL = float(os.getenv("FENRIR_MIN_RECALL", "0.70"))
FEATURES = ["file_entropy", "suspicious_strings", "network_connections", "persistence_signals"]
