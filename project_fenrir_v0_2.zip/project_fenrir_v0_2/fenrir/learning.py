import hashlib, ipaddress, json, math, random, re, uuid
from datetime import datetime, timezone
from pathlib import Path
from .config import (DATA_DIR, MODEL_DIR, INDICATORS_FILE, LABELED_FILE,
                     REGISTRY_FILE, FEATURES, MIN_TRAIN_SAMPLES,
                     MIN_PRECISION, MIN_RECALL)
from .events import append_event

DOMAIN_RE = re.compile(r"^(?=.{1,253}$)(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\\.)+[A-Za-z]{2,63}$")

def _read_jsonl(path):
    if not path.exists(): return []
    rows = []
    for n, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip(): continue
        try: rows.append(json.loads(line))
        except json.JSONDecodeError: raise ValueError(f"Invalid JSON on line {n}")
    return rows

def import_feed(path, source):
    p = Path(path).expanduser().resolve(strict=True)
    if not p.is_file(): raise ValueError("Feed path must be a regular file")
    existing = _read_jsonl(INDICATORS_FILE)
    known = {(x.get("type"), x.get("value")) for x in existing}
    accepted, rejected = 0, 0
    additions = []
    for row in _read_jsonl(p):
        typ, value = row.get("type"), str(row.get("value", "")).strip()
        valid = False
        if typ == "sha256": valid = bool(re.fullmatch(r"[0-9a-fA-F]{64}", value))
        elif typ == "ipv4":
            try: ipaddress.IPv4Address(value); valid = True
            except ValueError: pass
        elif typ == "domain": valid = bool(DOMAIN_RE.fullmatch(value))
        confidence = row.get("confidence", 0.5)
        if not valid or not isinstance(confidence, (int, float)) or not 0 <= confidence <= 1:
            rejected += 1; continue
        key = (typ, value.lower())
        if key in known: continue
        additions.append({"type": typ, "value": value.lower(), "source": source,
                          "confidence": float(confidence),
                          "observed_at": row.get("observed_at"),
                          "imported_at": datetime.now(timezone.utc).isoformat()})
        known.add(key); accepted += 1
    if additions:
        with INDICATORS_FILE.open("a", encoding="utf-8") as f:
            for item in additions: f.write(json.dumps(item) + "\\n")
    append_event("feed_import", "info", "Threat intelligence feed imported",
                 {"source": source, "accepted": accepted, "rejected": rejected})
    return {"accepted": accepted, "rejected": rejected, "total_indicators": len(known)}

def add_labeled_sample(sample):
    if not isinstance(sample, dict) or sample.get("label") not in (0, 1):
        raise ValueError("Sample must contain binary label 0 or 1")
    if sample.get("reviewed") is not True:
        raise ValueError("Only human-reviewed labels may enter the training set")
    feats = sample.get("features", {})
    clean = {}
    for name in FEATURES:
        value = feats.get(name)
        if not isinstance(value, (int, float)) or not math.isfinite(value):
            raise ValueError(f"Missing or invalid numeric feature: {name}")
        clean[name] = float(value)
    record = {"id": sample.get("id") or str(uuid.uuid4()), "features": clean,
              "label": int(sample["label"]), "source": str(sample.get("source", "unknown")),
              "reviewed": True}
    LABELED_FILE.parent.mkdir(parents=True, exist_ok=True)
    with LABELED_FILE.open("a", encoding="utf-8") as f: f.write(json.dumps(record) + "\\n")
    return record

def _sigmoid(z):
    z = max(-30.0, min(30.0, z))
    return 1.0 / (1.0 + math.exp(-z))

def _vector(row):
    return [float(row["features"][f]) for f in FEATURES]

def _train(rows, epochs=250, lr=0.03):
    # Standardize using training partition only.
    xs = [_vector(r) for r in rows]
    means = [sum(x[j] for x in xs) / len(xs) for j in range(len(FEATURES))]
    stds = []
    for j, mean in enumerate(means):
        variance = sum((x[j] - mean) ** 2 for x in xs) / max(1, len(xs)-1)
        stds.append(max(math.sqrt(variance), 1e-6))
    scaled = [[(x[j]-means[j])/stds[j] for j in range(len(FEATURES))] for x in xs]
    weights = [0.0] * len(FEATURES); bias = 0.0
    for _ in range(epochs):
        order = list(range(len(rows)))
        random.Random(17 + _).shuffle(order)
        for i in order:
            p = _sigmoid(sum(weights[j]*scaled[i][j] for j in range(len(weights))) + bias)
            error = p - rows[i]["label"]
            for j in range(len(weights)): weights[j] -= lr * error * scaled[i][j]
            bias -= lr * error
    return {"features": FEATURES, "means": means, "stds": stds, "weights": weights,
            "bias": bias, "threshold": 0.5, "created_at": datetime.now(timezone.utc).isoformat()}

def predict(model, features):
    vals = [float(features[f]) for f in model["features"]]
    scaled = [(vals[j]-model["means"][j])/model["stds"][j] for j in range(len(vals))]
    score = _sigmoid(sum(model["weights"][j]*scaled[j] for j in range(len(vals))) + model["bias"])
    return {"score": round(score, 5), "prediction": int(score >= model["threshold"])}

def _metrics(model, rows):
    tp=fp=tn=fn=0
    for row in rows:
        pred = predict(model, row["features"])["prediction"]; actual = row["label"]
        if pred and actual: tp += 1
        elif pred and not actual: fp += 1
        elif not pred and not actual: tn += 1
        else: fn += 1
    precision = tp/max(1,tp+fp); recall = tp/max(1,tp+fn)
    f1 = 2*precision*recall/max(1e-12,precision+recall)
    return {"tp":tp,"fp":fp,"tn":tn,"fn":fn,"precision":round(precision,4),
            "recall":round(recall,4),"f1":round(f1,4),"evaluated":len(rows)}

def _registry():
    if REGISTRY_FILE.exists(): return json.loads(REGISTRY_FILE.read_text(encoding="utf-8"))
    return {"active": None, "candidates": [], "history": []}

def train_candidate():
    rows = [r for r in _read_jsonl(LABELED_FILE) if r.get("reviewed") is True]
    if len(rows) < MIN_TRAIN_SAMPLES: raise ValueError(f"Need at least {MIN_TRAIN_SAMPLES} reviewed samples; found {len(rows)}")
    if {r.get("label") for r in rows} != {0,1}: raise ValueError("Training set must contain both benign (0) and malicious (1) labels")
    random.Random(42).shuffle(rows)
    split = max(1, int(len(rows)*0.8))
    train_rows, test_rows = rows[:split], rows[split:]
    if not test_rows: raise ValueError("Not enough data for holdout evaluation")
    model = _train(train_rows)
    metrics = _metrics(model, test_rows)
    candidate_id = "cand-" + uuid.uuid4().hex[:12]
    model["candidate_id"] = candidate_id
    model["metrics"] = metrics
    model["eligible_for_review"] = metrics["precision"] >= MIN_PRECISION and metrics["recall"] >= MIN_RECALL
    model_path = MODEL_DIR / f"{candidate_id}.json"
    model_path.write_text(json.dumps(model, indent=2), encoding="utf-8")
    reg = _registry(); reg["candidates"].append({"id":candidate_id,"path":str(model_path),
       "metrics":metrics,"eligible_for_review":model["eligible_for_review"],"status":"pending"})
    REGISTRY_FILE.write_text(json.dumps(reg, indent=2), encoding="utf-8")
    append_event("model_training", "info", "Candidate model trained; not active",
                 {"candidate_id":candidate_id,"metrics":metrics})
    return {"candidate_id":candidate_id,"metrics":metrics,
            "eligible_for_review":model["eligible_for_review"],"status":"pending_human_approval"}

def approve_candidate(candidate_id):
    reg = _registry()
    candidate = next((c for c in reg["candidates"] if c["id"] == candidate_id), None)
    if not candidate: raise ValueError("Candidate not found")
    if not candidate["eligible_for_review"]: raise ValueError("Candidate did not meet configured precision/recall gates")
    model = json.loads(Path(candidate["path"]).read_text(encoding="utf-8"))
    version = "model-" + datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S")
    model["version"] = version
    target = MODEL_DIR / f"{version}.json"
    target.write_text(json.dumps(model, indent=2), encoding="utf-8")
    previous = reg.get("active")
    if previous: reg["history"].append(previous)
    reg["active"] = {"version":version,"path":str(target),"approved_at":datetime.now(timezone.utc).isoformat()}
    candidate["status"] = "approved"
    REGISTRY_FILE.write_text(json.dumps(reg, indent=2), encoding="utf-8")
    append_event("model_promotion", "info", "Human-approved model promoted",
                 {"version":version,"previous":previous})
    return {"active":reg["active"],"previous":previous}

def rollback(version):
    reg = _registry()
    item = next((x for x in reg["history"] if x.get("version") == version), None)
    if not item: raise ValueError("Version not found in rollback history")
    current = reg.get("active")
    if current: reg["history"].append(current)
    reg["history"] = [x for x in reg["history"] if x.get("version") != version]
    reg["active"] = item
    REGISTRY_FILE.write_text(json.dumps(reg, indent=2), encoding="utf-8")
    append_event("model_rollback", "medium", "Active model rolled back", {"version":version})
    return {"active":reg["active"]}

def learning_status():
    reg = _registry()
    return {"sample_count":len(_read_jsonl(LABELED_FILE)),
            "indicator_count":len(_read_jsonl(INDICATORS_FILE)),
            "active_model":reg.get("active"),
            "candidates":reg.get("candidates",[])[-10:],
            "model_dir":str(MODEL_DIR)}
