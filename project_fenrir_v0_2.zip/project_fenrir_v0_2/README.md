# PROJECT FENRIR — Learning Engine v0.2.0

Hybrid, lightweight defensive learning engine for Kali Linux on WSL2:
- local, pure-Python logistic-regression model (no heavyweight ML runtime)
- offline threat-intelligence import from JSONL
- feature validation and source provenance
- train/evaluate candidate models
- explicit human approval before promotion
- model versioning and rollback
- FastAPI dashboard and API

This is a defensive research prototype, not a complete antivirus. It does not
execute malware, scan arbitrary public targets, propagate, or automatically
change its active model. Feed ingestion is file-based in this release.

## Requirements
Python 3.11+, Kali Linux WSL2. Rust stable is optional for the Rust hash core.

## Install
```bash
sudo apt update
sudo apt install -y python3 python3-venv python3-pip cargo rustc
unzip project_fenrir_v0_2.zip
cd project_fenrir_v0_2
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
uvicorn fenrir.app:app --host 127.0.0.1 --port 8080
```
Open http://127.0.0.1:8080 in your Windows browser.

## Learning workflow
1. Import reviewed, trusted JSONL feed data:
```bash
python -m fenrir.cli import-feed samples/example_feed.jsonl --source example-lab
```
2. Add labeled training records (one JSON object per line) to `data/labeled_samples.jsonl`.
   Schema:
```json
{"id":"sample-001","features":{"file_entropy":0.91,"suspicious_strings":4,"network_connections":12,"persistence_signals":1},"label":1,"source":"isolated-lab","reviewed":true}
```
Labels: `1` suspicious/malicious, `0` benign. Do not label from filename alone.
3. Train and evaluate:
```bash
python -m fenrir.cli train
```
4. Inspect candidate metrics:
```bash
python -m fenrir.cli status
```
5. Promote only after review:
```bash
python -m fenrir.cli approve CANDIDATE_ID
```
6. Roll back to a previous approved model:
```bash
python -m fenrir.cli rollback MODEL_VERSION
```

Training requires at least 20 reviewed samples and both classes. The evaluator
uses a deterministic holdout split. A candidate is not active until a human
approves it. A candidate must meet configured precision/recall gates.

## Feed format
JSONL records:
```json
{"type":"sha256","value":"<64 hex chars>","source":"lab-feed","confidence":0.95,"observed_at":"2026-01-01T00:00:00Z"}
```
Supported types in this prototype: `sha256`, `domain`, `ipv4`. Imported indicators
are stored as intelligence data, not executed or contacted. Only import feeds
from sources whose terms permit your use.

## API
- `GET /api/status`
- `GET /api/learning/status`
- `POST /api/learning/import` with `{"path":"samples/example_feed.jsonl","source":"example-lab"}`
- `POST /api/learning/train`
- `POST /api/learning/approve` with `{"candidate_id":"..."}`
- `POST /api/learning/rollback` with `{"version":"..."}`
- `GET /api/learning/indicators`
- `GET /api/events`

The dashboard binds to localhost only. Do not expose it publicly.

## Safety and limitations
- No automatic model promotion.
- No remote feed fetching in v0.2; feeds are imported from local files.
- No malware execution or detonation. Use a disposable, isolated VM for any
  future sample analysis.
- A hash or feed match is an indicator, not proof of infection.
- Model scores are triage signals, not definitive malware verdicts.
- Protect `data/`, review training labels, and back up the model registry.
