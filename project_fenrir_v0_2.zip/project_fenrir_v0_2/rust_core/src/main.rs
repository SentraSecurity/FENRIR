use sha2::{Digest, Sha256};
use std::{env, fs::File, io::Read};
fn main() {
    let a: Vec<String> = env::args().collect();
    if a.len()!=3 || a[1]!="hash" { eprintln!("Usage: fenrir-core hash <file>"); std::process::exit(2); }
    let mut f=File::open(&a[2]).expect("cannot open file");
    let mut h=Sha256::new(); let mut b=[0u8;65536];
    loop { let n=f.read(&mut b).expect("read failed"); if n==0 {break;} h.update(&b[..n]); }
    println!("{}",hex::encode(h.finalize()));
}
